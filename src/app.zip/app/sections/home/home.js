app.controller('homeCtrl', ['$scope', function ($scope) {
$scope.new1 = "";
    $('#n1').addClass("current");
    $('#n3, #n2 , #n4, #n5').removeClass("current");
}]);
